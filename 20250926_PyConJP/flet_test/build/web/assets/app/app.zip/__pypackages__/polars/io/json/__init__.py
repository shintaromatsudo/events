from polars.io.json.read import read_json

__all__ = ["read_json"]
